#include "queue.h"

//init
queue* queue_init(queue *q, int queue_size) {
	q->array = malloc(queue_size * sizeof(node));
    q->size = 0;
	q->maxsize = queue_size;
	q->front = 0;
	q->rear = -1;//-1 since we increment in enqueue
	
	return q;
}

void enqueue(queue *q, void *x) {//last in
    //check if there is space to enqueue
	if(isFull(q)) {
		printf("Error: Full queue cannot add more nodes\n");
		return -1; //error
	}
    //if there is proceed
	q->rear = (q->rear + 1) % q->maxsize;//append to rear
	q->array[q->rear].val = x;
	q->size++;
    return 1; //success
}

void* dequeue(queue *q) {//first out
    //check if there are nodes to dequeue
	if(isEmpty(q)) {
		printf("Error: Empty queue cannot pop any nodes\n");
		return -1; //error
	}
    //if there is proceed
	void *value = q->array[q->front].val;//get first value
	q->array[q->front].val = NULL;//delete from queue
	q->front = (q->front + 1) % q->maxsize;//move front
	q->size--;
	return value;
}

int size(queue *q) {
	return q->size;
}

//1 if full 0 if not
int isFull(queue *q) {
	return (q->size == q->maxsize);
}

//1 if empty 0 if not
int isEmpty(queue *q) {
	return (q->size == 0);
}

// Free the queue
void queue_cleanup(queue *q) {
	while(q->size > 0) {//while things in queue dequeue and free up mem for val
		void * val;
		val = dequeue(q);
		free(val);
	}
    //free up mem
	free(q->array);
}
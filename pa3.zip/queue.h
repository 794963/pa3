#ifndef QUEUE_H
#define QUEUE_H

#include <stdio.h>
#include <stdlib.h>

typedef struct node_type {
	void *val;
} node;

typedef struct queue_type {
	node *array;
	int size;
	int maxsize;
	int front;
	int rear;
} queue;


queue* queue_init(queue *q, int size);

void enqueue(queue *q, void* element);

void* dequeue(queue *q);

int size(queue *q);

int isFull(queue *q);

int isEmpty(queue *q);

void queue_cleanup(queue *q);

#endif
#ifndef MULTI_LOOKUP_H
#define MULTI_LOOKUP_H

#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <unistd.h>

#include "queue.h"
#include "util.h"

// Limits and shared buffer size
#define ARRAY_SIZE 8
#define MAX_INPUT_FILES 100
#define MAX_RESOLVER_THREADS 10
#define MAX_REQUESTER_THREADS 10
#define MAX_DOMAIN_NAME_LENGTH 1025
#define MAX_IP_LENGTH INET6_ADDRSTRLEN

// Requester struct
typedef struct req {
	FILE* qLog;//requestor log file
	queue* fileNames;//filename queue
	queue* buffer;//shared buffer b/t req and res
	pthread_mutex_t* m;// Shared buffer mutex
	pthread_mutex_t* queue_lock;// filename queue mutex
	pthread_mutex_t* qLog_lock;// reQuester log mutex
    pthread_cond_t* req_condition;//requester condition variable
	pthread_cond_t* res_condition;//resolver condition variable
} requester;

// Resolver struct (dont need file name queue)
typedef struct res {
	FILE* sLog;//requestor log file
	queue* buffer;//shared buffer b/t req and res
	pthread_mutex_t* m;//shared buffer mutex
	pthread_mutex_t* sLog_lock;//reSolver log mutex
    pthread_cond_t* req_condition;//requester condition variable
	pthread_cond_t* res_condition;//resolver condition variable
	int* rDone;//1 if requesters done 0 if not
} resolver;

void *request(void* data);

void *resolve(void* data);

#endif

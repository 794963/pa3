#include "multi-lookup.h"

void *request(void* r) {
	requester* req = (requester*) r;
	int file_count  = 0;
    bool done = false;
	while(!done) {
		pthread_mutex_lock(req->queue_lock);//queue lock
		if(size(req->fileNames) > 0) {//size of queue > 0
			char* fileName = dequeue(req->fileNames);
			file_count++;
			pthread_mutex_unlock(req->queue_lock);
			FILE* file = fopen(fileName, "r");//open for reading
			char line[MAX_DOMAIN_NAME_LENGTH];
			while(fgets(line, sizeof(line), file)) {//while fgets reading lines
				pthread_mutex_lock(req->m);//lock buffer
				while(isFull(req->buffer)) {
					pthread_cond_wait(req->req_condition, req->m);//wait if full
				}
				enqueue(req->buffer, strndup(strtok(line, "\n"), strlen(line)));//get rid of eol char
				pthread_mutex_unlock(req->m);//unlock buffer
				
				pthread_cond_signal(req->res_condition);//signal resolver
			}
			fclose(file);
			free(fileName);
		} 
		else {
			pthread_mutex_unlock(req->queue_lock);//queue unlock
			done = true; //exit while loop
		}
	}
	// Write to the requester log
	pthread_mutex_lock(req->qLog_lock);
	fprintf(req->qLog, "Thread %ld serviced %d files.\n", syscall(SYS_gettid), file_count);
	pthread_mutex_unlock(req->qLog_lock);
	return 0;
}

void *resolve(void* r) {
	resolver* res = (resolver*) r;
	char *ip = malloc(MAX_IP_LENGTH);//ip address init
    bool done = false;
	while(!done) {
		pthread_mutex_lock(res->m);//lock buffer
		if((size(res->buffer) > 0) || (*(res->rDone) == 0)) {//if requesters not done or buffer empty
			while(isEmpty(res->buffer)) {
				pthread_cond_wait(res->res_condition, res->m);//wait while isEmpty
			}
			char* domain = dequeue(res->buffer);//get domain
			pthread_mutex_unlock(res->m);//unlock buffer
			pthread_cond_signal(res->req_condition);//signal requester at isFull wait
            int i = dnslookup(domain, ip, MAX_IP_LENGTH);//lookup ip and assign return val to i
			if(i) {//-1 if failure 0 if success so...
				// Error
				pthread_mutex_lock(res->sLog_lock);//lock res log
				fprintf(stderr, "Bad hostname, IP not found for domain: %s\n", domain);//print error to stderr
				fprintf(res->sLog, "%s,\n", domain);//only domain to log file
				pthread_mutex_unlock(res->sLog_lock);//unlock reslog
			} 
			else {
                //Success
				pthread_mutex_lock(res->sLog_lock);//lock res log
				fprintf(res->sLog, "%s,%s\n", domain, ip);
				pthread_mutex_unlock(res->sLog_lock);//unlock res log
			}
			free(domain);//free mem
		} 
		else {
			pthread_mutex_unlock(res->m);//unlock buffer
			done = true;//exit while loop
		}
	}
	free(ip);//free mem
	return 0;
}


int main(int argc, char* argv[]) {
	//time
	struct timeval start, stop;
	gettimeofday(&start, NULL);

	
	// Check for for arg length error
	if(argc <= 5) {
		fprintf(stderr, "Not enough input arguments\n");
		return -1;
	} else if(argc > 5 + MAX_INPUT_FILES) {
		fprintf(stderr, "Too many input files\n");
		return -1;
    //create files if they dont exist
    if(access(argv[3], F_OK) == -1) {
		FILE* qLog = fopen(argv[3] ,"a");//reQuest create file
	}
	if(access(argv[4], F_OK) == -1) {
		FILE* sLog = fopen(argv[4] ,"a");//reSolver create file
	}


	//Add input files 
	queue files;
	queue_init(&files, MAX_INPUT_FILES);
	for(int i = 5; i < argc; i++) { //iterate 
		if(access(argv[i], F_OK) == -1) {
			fprintf(stderr, "invalid filename: %s\n", argv[i]);
		} else {
			enqueue(&files, strndup(argv[i], strlen(argv[i])));
		}
	}

	// Mutex and condition variables
	pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_t queue_lock = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_t qLog_lock = PTHREAD_MUTEX_INITIALIZER;
	pthread_mutex_t sLog_lock = PTHREAD_MUTEX_INITIALIZER;
	pthread_cond_t req_condition = PTHREAD_COND_INITIALIZER;
	pthread_cond_t res_condition = PTHREAD_COND_INITIALIZER;

	//Struct initialization
	int rDone = 0;
	queue buffer;
	queue_init(&buffer, ARRAY_SIZE);
    //requester
	requester req;
	req.qLog = fopen(argv[3], "w");//open for writing
	req.fileNames = &files;
	req.buffer = &buffer;
	req.m = &m;
	req.req_condition = &req_condition;
	req.res_condition = &res_condition;
	req.queue_lock = &queue_lock;
	req.qLog_lock = &qLog_lock;
    //resolver
	resolver res;
	res.sLog = fopen(argv[4], "w");//open for writing
	res.buffer = &buffer;
	res.m = &m;
	res.req_condition = &req_condition;
	res.res_condition = &res_condition;
	res.sLog_lock = &sLog_lock;
	res.rDone = &rDone;


    int qNum = atoi(argv[1]);
	pthread_t req_tid[qNum];
	for(int i = 0; i < qNum; i++) {
		pthread_create(&req_tid[i], NULL, request, &req);
	}

    
	int sNum = atoi(argv[2]);
    pthread_t res_tid[sNum];
	for(int i = 0; i < sNum; i++) {
		pthread_create(&res_tid[i], NULL, resolve, &res);
	}
	
    //wait for requester threads to terminate
	for(int i = 0; i < qNum; i++) {
	    pthread_join(req_tid[i], NULL);
	}

	pthread_mutex_lock(&m);
    rDone = 1;//will be changed once requesters done
    pthread_mutex_unlock(&m);
    
    //wait for resolver threads to terminate
    for(int i = 0; i < sNum; i++) {
	    pthread_join(res_tid[i], NULL);
    }

    //cleanup
    fclose(req.qLog);
    fclose(res.sLog);
    queue_cleanup(&files);
    queue_cleanup(&buffer);
    gettimeofday(&stop, NULL);

    // Print stats
    printf("Total Run Time: %ld seconds\n", (stop.tv_sec-start.tv_sec) + (stop.tv_usec-start.tv_usec)/1000000);
	return 0;
}
}
